import requests
import json
import os
from base64 import b64decode
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.padding import PKCS7
from cryptography.hazmat.primitives import serialization, hashes, hmac, asymmetric, padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

URL = 'https://unicorntheoriest.me:23245/server'
f=open('private.pem', 'rb')
fread=open('private.pem', 'r')
private_key_load = serialization.load_pem_private_key(
    f.read(),
    password=None,
    backend=default_backend()
)
private_key = private_key_load.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
        )
public_key = private_key_load.public_key()
pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
#getData = {'name': 'private.pem', 'key': private_key}
#rprivate = requests.post(URL, data={'name': 'test2.pem', 'private_key': private_key, 'public_key': pem }, files=[('file', f), ('file', pem)])
#print(rprivate.status_code, rprivate.reason, " ---> private.pem POST request has succeeded.")

rprivate = requests.get(URL, params = {'private_key': private_key.decode("utf-8")})
data = json.loads(rprivate.text)
f.close()
f=open('newprivate.pem', 'w')
f.write(data['private_key'])
f.close()
f=open('newpublic.pem', 'w')
f.write(data['public_key'])
f.close()
